<!DOCTYPE html>
<?php
      $fifa55Main = 'FIFA55EURO';
      ?>
<html class="no-js">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <meta content="black" name="apple-mobile-web-app-status-bar-style">
      <title><?=$fifa55Main;?> เว็บพนันบอล คาสิโนออนไลน์ อันดับ 1 </title>
      <link rel="icon" href="images/logoicon.html">
      <base  />
      <meta name="description" content="เว็บ แทงบอลออนไลน์ อันดับ 1 ต้อง <?=$fifa55Main;?> ให้บริการ แทงบอล แทงหวย คาสิโน fifa55 อย่างเป็นทางการให้บริการ 24 ชม." />
      <META NAME="ROBOTS" CONTENT="INDEX,FOLLOW" />
      <META NAME="KEYWORDS" CONTENT="แทงบอลออนไลน์,แทงบอล,fifa55,fifa555,พนันบอล,เว็บพนัน,รับแทงบอล,รับแทงบอลออนไลน์ 088-207-5555" />
      <meta property="og:image" content="files/com_banner/2017-06/2017-06_7fa4e872121ae8e.gif"  />
      <!-- jQuery 2.1.3 -->
      <script type="text/javascript" src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
      <!-- Style Sheets -->
      <link href="font.css" rel="stylesheet" type="text/css" />
      <!-- Styling -->
      <link href="style/core.css" rel="stylesheet">
      <script>
         var txt_blank    = 'กรุณากรอกข้อมูลให้ครบ';
         var txt_tel      = 'กรุณากรอกหมายเลขโทรศัพท์ให้ถูกต้อง';
         var txt_success  = 'สำเร็จ !! กรุณารอการติดต่อกลับจากเจ้าหน้าที่';
         var txt_fail     = 'เกิดข้อผิดพลาดในการส่งข้อมูล';
         var exits_tel    = 'ท่านได้ใช้หมายเลขนี้สมัครสมาชิกแล้ว';
      </script>
      
   </head>
   <body>
      <!-- MAIN PAGE CONTAINER -->
      <div class="boxed-container">
         <div class="top">
            <div class="container">
               <div class="pre-header-area">
                  <div class="pre-header-left left" id="top-h-lef">
                     <!-- Second Nav -->
                     <ul>
                        <li><a href=""><?=$fifa55Main;?> เว็บพนันบอล คาสิโนออนไลน์ อันดับ 1 </a></li>
                     </ul>
                  </div>
                  <div class="pre-header-right right">
                     <ul class="clearfix">
                        
                        <span class="pipe-bar">| &nbsp;</span>
                        <li><a href="https://www.fifa55.com/">ทางเข้าเล่น</a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <!-- /.top -->
         <!-- HEADER -->
         <div class="header-container" style=" height: 70px;">
            <div class="container">
               <header class="header">
                  <div class="header__logo">
                     <a class="logo" href="">
                     <img class="img-responsive" src="images/logo/logo.png" alt="FiFA55BOX" style=" margin-top: -12px;">
                     </a>
                     <div id="mobile-header">
                        <a id="responsive-menu-button" href="#sidr-main">
                           <em class="fa fa-bars" style="font-size: 45px;color: #fdfdfd;"></em>  
                        </a>
                     </div>
                  </div>
                  <div class="header-navigation" id="navigation-only">
                      
                  </div>
                  <div class="header-widgets">
 
                  </div>
               </header>
            </div>
         </div>
         <div class="outter-wrapper body-wrapper promotion-theme">
            <div class="wrapper section-promotion clearfix">
               <div class="col-md-6">
                  <img src="images/promotion/promote.png" class="img-responsive wow tada" data-wow-offset="50" data-wow-delay="1.5s"> 
               </div>
               <div class="col-md-6 last">
                  <header>โปรโมชั่น</header>
                  <p>โปรโมชั่นพิเศษ ที่ทาง <?=$fifa55Main;?> มอบให้คุณ</p>
                  <ul class="promotion">
                     <li class="wow bounceInRight" data-wow-delay="0.2s"  >
                        <i class="fa fa-chevron-circle-right icon-maginr" aria-hidden="true"></i> แนะนำเพื่อน รับไปเลย 20% 
                     </li>
                     <li class="wow bounceInRight" data-wow-delay="0.4s"  >
                        <i class="fa fa-chevron-circle-right icon-maginr" aria-hidden="true"></i> บอลสเต็ปรับส่วนลด 20% 
                     </li>
                     <li class="wow bounceInRight" data-wow-delay="0.6s"  >
                        <i class="fa fa-chevron-circle-right icon-maginr" aria-hidden="true"></i> บอลเต็งรับส่วนลด 0.5% 
                     </li>
                  </ul>
                  <hr class="hr-pro">
                  <a href="https://www.fifa55.com/" class="btn btn-danger btn-lg pull-right Parent slideInUp animated" data-animate-offset="50" role="button" id="more-promotion"> <i class="fa fa-plus-circle promo-btn" aria-hidden="true"></i> โปรโมชั่นเพิ่มเติม</a>
               </div>
            </div>
         </div>
         <div class="header-top">
            <div class="auto-container clearfix">
               <!-- Top Left -->
               <div class="top-left">
                  <ul class="clearfix">
                     <li> &nbsp;&nbsp;<?=$fifa55Main;?>   MESSAGE </li>
                  </ul>
               </div>
               <!-- Top Right -->
               <div class="top-right">
                  <ul class="clearfix">
                     <li>
                        <marquee id="maquee-talk" truespeed="1" scrolldelay="50" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();">
                           <span>
                           &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-star orangge"></i> &nbsp;&nbsp;&nbsp; <?=$fifa55Main;?> ผู้ให้บริการ แทงบอลออนไลน์ คาสิโน หวยออนไลน์ อย่างเป็นทางการและมีมาตรฐานเป็นสากล กับการให้บริการที่ดี มั่นคง ปลอดภัย 100%
                           </span>
                        </marquee>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="outter-wrapper body-wrapper regist-theme">
            <div class="wrapper ad-pad-first clearfix regist-theme" >
               <div class="outter-wrapper body-wrapper" style="min-height: 430px  !important;">
   <div class="wrapper blog-roll ad-pad clearfix">
      <!-- Start Main Column  -->
      <div class="col-sm-12 col-md-9 body-sub screen-w-right-in">
         <div class="clearfix post body-main-sub">
            <div class="body-main-sub-in listf-1">
               <p><span style="color:#c1212c"><span style="font-size:42px"><span style="font-family:pslxkittithadabold">อัพเดททางเข้าเล่น</span></span></span></p>
               <p><span style="font-size:26px"><span style="font-family:thsarabunnewregular">&nbsp; &nbsp; &nbsp; &nbsp;ทางเข้า FIFA55 หากกรณีที่ทางเข้าอันเดิมที่ท่านสมาชิกใช้อยู่ เกิดขัดข้องเข้าไม่ได้หรือทางเว็บ FIFA55&nbsp;มีการปรับปรุงทางเข้าใหม่ เราทีมงาน <?=$fifa55Main;?>.COM&nbsp;ก็จะทำการอัพเดททางเข้าอันใหม่ไว้ที่หน้าเพจนี้</span></span></p>
               <ul>
               <?php
               $arrLink = array('fifa55winner'=>'www.fifa55winner.com','fifa55euro'=>'www.fifa55euro.com','fifa55cup'=>'www.fifa55cup.com','fifa55world'=>'www.fifa55world.com','fifa55shoot'=>'www.fifa55shoot.com','fifa55box'=>'www.fifa55box.com');
               ?>
               <?php
               $i=1;
               foreach($arrLink as $name=>$link){
               ?>
                  <li>
                  <span style="font-size:28px">
                  <span style="font-family:pslxkittithadabold">
                  <span style="font-size:26px">
                  <span style="font-family:thaisanslite">
                  ทางเข้าที่ <?=$i;?> :
                  <span style="font-size:28px">&nbsp;</span>
                  </span>
                  <span style="font-size:28px">
                  <span style="font-family:thsarabunnewregular">
                  <a href="http://<?=$name;?>.com" target="_blank">
                  <span style="color:#000080"><?=$link;?></span>
                  </a>
                  </span>
                  </span>
                  </span>
                  </span>
                  </span>
                  </li>
                  <?php $i++;} ?>
               </ul>
               <p>&nbsp;</p>
               <p>&nbsp;</p>
            </div>
         </div>
      </div>
      <!-- Start Right Sidebar  -->
      <aside class="col-sm-12 col-md-3 screen-w-right-2">
         <div class="widget">
            <div class="widget-ads-r wow bounceIn" data-wow-delay="1s" style="text-align: -webkit-center; visibility: visible; animation-delay: 1s; animation-name: bounceIn;">
               <img src="images/subpage/ads-right.png" class="img-responsive">
            </div>
            <h1 class="h-text-contact contact-sub-left  wow zoomIn" style="visibility: visible; animation-name: zoomIn;">ติดต่อเรา</h1>
            <ul class="widget-list contact-list">
               <li class="wow zoomInRight" data-wow-delay="0.4s" onclick="window.open('https://line.me/ti/p/', '_blank')" style="visibility: visible; animation-delay: 0.4s; animation-name: zoomInRight;"><img src="images/contact/svg/line.svg" style="width: 40px;"> 		<span class="contact-list-style"></span></li>
               <li class="wow zoomInRight" data-wow-delay="0.6s" onclick="window.open('https://www.facebook.com/<?=$fifa55Main;?>', '_blank')" style="visibility: visible; animation-delay: 0.6s; animation-name: zoomInRight;"><img src="images/contact/svg/facebook.svg" style="width: 40px;"> 	<span class="contact-list-style"> <?=$fifa55Main;?></span></li>
               <li class="wow zoomInRight" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: zoomInRight;"><img src="images/contact/svg/email.svg" style="width: 40px;"> 		<span class="contact-list-style"><?=$fifa55Main;?>@gmail.com </span></li>
               <li class="wow zoomInRight" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: zoomInRight;"><img src="images/contact/svg/internet.svg" style="width: 40px;"> 	<span class="contact-list-style">www.<?=$fifa55Main;?>.com</span></li>
            </ul>
         </div>
         <div>
         </div>
      </aside>
   </div>
</div>
            </div>
         </div>
         <div class="outter-wrapper body-wrapper wrapper-services">
            <div class="wrapper ad-pad clearfix" >
               <div class="row box-highlight">
                  <div class="service-recomend wow pulse" data-wow-delay="0.2s">
                     <img src="images/service/service.jpg" class="img-responsive">
                  </div>
                  <div class="itemhov itemhov-type-line wow pulse" data-wow-delay="0.2s">
                     <a class="itemhov-hover" href="#">
                        <div class="itemhov-info">
                           <div class="headline">กีฬาออนไลน์</div>
                           <div class="line"></div>
                           <div class="dat">START BETTING</div>
                        </div>
                        <div class="mask"></div>
                     </a>
                     <div class="itemhov-img"><a href="#"><img src="images/service/service1.jpg" /></a></div>
                  </div>
                  <div class="itemhov itemhov-type-line wow pulse" data-wow-delay="0.2s">
                     <a class="itemhov-hover" href="service/casino.html">
                        <div class="itemhov-info">
                           <div class="headline">คาสิโนออนไลน์</div>
                           <div class="line"></div>
                           <div class="dat">START BETTING</div>
                        </div>
                        <div class="mask"></div>
                     </a>
                     <div class="itemhov-img"><a href="service/casino.html"><img src="images/service/service2.jpg" /></a></div>
                  </div>
                  <div class="itemhov itemhov-type-line wow pulse" data-wow-delay="0.2s">
                     <a class="itemhov-hover" href="#">
                        <div class="itemhov-info">
                           <div class="headline">หวยออนไลน์</div>
                           <div class="line"></div>
                           <div class="dat">START BETTING</div>
                        </div>
                        <div class="mask"></div>
                     </a>
                     <div class="itemhov-img"><a href="#"><img src="images/service/service3.jpg" /></a></div>
                  </div>
                  <div class="service-under wow pulse" data-wow-delay="0.4s">
                     <img src="images/service/service4.jpg" class="img-responsive" >
                  </div>
               </div>
            </div>
         </div>
         <div class="outter-wrapper body-wrapper">
            <div class="wrapper ad-pad-first clearfix" >
               <div class="col-xs-12">
                  <div class="simple-column">
                     <div class="heading heading-12">
                        <p >ABOUT US</p>
                        <h1 class="wow zoomInUp"><span class="left"></span>FIFA55 บริการเดิมพันออนไลน์อันดับ 1<span class="right"></span></h1>
                        <div class="wow fadeIn descript-about" data-wow-delay="1.2s" data-wow-duration="1s">
                           <p>&nbsp;</p>
                           <p>FIFA55 เว็บออนไลน์อันดับหนึ่ง เว็บตรง มั่นคง ปลอดภัย 100%</p>
                           <p><span style="color:#000000"><?=$fifa55Main;?>.COM</span>&nbsp;เว็บแทงบอลออนไลน์ หวยออนไลน์ คาสิโนออนไลน์ และอื่นๆ</p>
                           <p>&nbsp;</p>
                           <p>FIFA55&nbsp;เว็บแทงบอลออนไลน์ คาสิโนออนไลน์ <?=$fifa55Main;?> เป็นเว็บที่ไม่ผ่านเอเย่นต์ แก้ปัญหาเรื่องการโกงจากตัวแทนต่างๆ FIFA55&nbsp;ฉีกกฎของเว็บแทงบอลเดิมๆ ที่คุณเคยใช้งานอยู่ และจุดเด่น <?=$fifa55Main;?>&nbsp;คือ รวมทุกอย่างไว้ในไอดีเดียวเลย&nbsp;</p>
                           <p>&nbsp;</p>
                           <p>FIFA55&nbsp;มีทีมงานคุณภาพ และมีออฟฟิศจริง&nbsp;อยู่ที่ สำนักงานใหญ่ อาคาร Princess Holiday Palace ปอยเปตประเทศกัมพูชา เพื่อตอบสนองความต้องการของนักเสี่ยงโชคทุกท่าน&nbsp;&nbsp;<?=$fifa55Main;?>&nbsp;มีบริการ Call Center 24 ชั่วโมง รองรับการสมัครหรือสอบถามข้อมูลต่างๆ</p>
                           <p>&nbsp;</p>
                           <p>FIFA55&nbsp;มีช่องทางอื่นๆ ผ่านทางสื่อต่างอีกมากมาย ทั้งทางโทรศัพท์ Line, &nbsp;Line@, Facebook, Livechat, E-mail</p>
                           <p><?=$fifa55Main;?> ได้เพิ่มช่องทางการติดต่อให้ทันสมัยอยู่ตลอดเวลา เพื่อป้องกันการที่สมาชิกของ&nbsp;FIFA55 จะหาช่องทางการติดต่อกับเราไม่ได้</p>
                           <p>&nbsp;</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="outter-wrapper body-wrapper wrapper-feature">
            <div class="wrapper ad-pad-first clearfix">
               <div class="col-xs-12">
                  <div class="simple-column">
                     <div class="heading heading-12 feature-des">
                        <h1 class="wow zoomInUp">เดิมพันออนไลน์ <?=$fifa55Main;?> ดีกว่ายังไง ?</h1>
                        <div class="descript-about">
                           <div class="row" id="sec4">
                              <!-- rows -->
                              <div class="col-md-4">
                                 <div class="media wow flipInX" data-wow-delay="0.3s">
                                    <div class="media-left">
                                       <i class="fa fa-futbol-o fa-4x"></i>
                                    </div>
                                    <div class="media-body">
                                       <h4 class="media-heading">FIFA55 เว็บคุณภาพ บริการ 24 ชม.</h4>
                                       สมาชิก FIFA55 ที่เข้ามาเดิมพันกับทางเว็บ <?=$fifa55Main;?> ไม่ต้องกังวลทางทีมงานพร้อมให้บริการอย่างเต็มที่โดยไร้ปัญหา
                                    </div>
                                 </div>
                                 <!--media-->
                              </div>
                              <div class="col-md-4">
                                 <div class="media wow flipInX" data-wow-delay="0.6s">
                                    <div class="media-left">
                                       <i class="fa fa-futbol-o fa-4x"></i>
                                    </div>
                                    <div class="media-body">
                                       <h4 class="media-heading">FIFA55 การเงินมั่นคง จ่ายจริง </h4>
                                       <?=$fifa55Main;?> เว็บตรงจาก FIFA55 ไม่ผ่านเอเย่นต์ การเงินมั่นคง จ่ายจริง จ่ายไว จ่ายไม่อั้น
                                    </div>
                                 </div>
                                 <!--media-->
                              </div>
                              <div class="col-md-4">
                                 <div class="media wow flipInX" data-wow-delay="0.9s">
                                    <div class="media-left">
                                       <i class="fa fa-futbol-o fa-4x"></i>
                                    </div>
                                    <div class="media-body">
                                       <h4 class="media-heading">FIFA55 โปรโมชั่นแจกแหลก</h4>
                                       FIFA55 เดิมพันออนไลน์สุดคุ้ม กับโปรโมชั่นสนุก ๆ ลุ้นรับรางวัลใหญ่ ที่ทางเราจัดให้สมาชิกกันตลอด
                                    </div>
                                 </div>
                                 <!--media-->
                              </div>
                              <div class="col-md-4">
                                 <div class="media wow flipInX" data-wow-delay="1.2s">
                                    <div class="media-left">
                                       <i class="fa fa-futbol-o fa-4x"></i>
                                    </div>
                                    <div class="media-body">
                                       <h4 class="media-heading">FIFA55 รวมทุกอย่างไว้ในบัญชีเดียว</h4>
                                       FIFA55 เดิมพันกีฬาออนไลน์หลายชนิด ไก่ชนออนไลน์ เล่นคาสิโนแบบสดๆ ทั้งหมดนี้อยู่ในบัญชีใช้งาน เพียงบัญชีเดียว !!
                                    </div>
                                 </div>
                                 <!--media-->
                              </div>
                              <div class="col-md-4">
                                 <div class="media wow flipInX" data-wow-delay="1.5s">
                                    <div class="media-left">
                                       <i class="fa fa-futbol-o fa-4x"></i>
                                    </div>
                                    <div class="media-body">
                                       <h4 class="media-heading">FIFA55 เล่นผ่านมือถือ ทุกที่ ทุกเวลา</h4>
                                       FIFA55 เล่นผ่านมือถือได้ตลอดทั้งวัน สะดวกสบาย ประหยัดเวลา ถูกใจนักเดิมพันที่เดินทางอยู่สม่ำเสมอ
                                    </div>
                                 </div>
                                 <!--media-->
                              </div>
                              <div class="col-md-4">
                                 <div class="media wow flipInX" data-wow-delay="1.8s">
                                    <div class="media-left">
                                       <i class="fa fa-futbol-o fa-4x"></i>
                                    </div>
                                    <div class="media-body">
                                       <h4 class="media-heading">ถ่ายทอดสดติดขอบสนามที่FIFA55</h4>
                                       สามารถรับชมการถ่ายทอดสดฟุตบอลได้ทุกลีกทั่วโลกที่ <?=$fifa55Main;?> คมชัดระดับ HD และไม่มีโฆษณามากวนใจตลอดการแข่งขันที่นี่
                                    </div>
                                 </div>
                                 <!--media-->
                              </div>
                           </div>
                        </div>
                        <!-- rows -->
                     </div>
                     <div class="row" style="text-align:center;" >
                        <h2 style="font-size:18px !important;padding:0;margin:0 auto;display:inline-block;">แทงบอลที่ไหนดี</h2>
                        <h2 style="font-size:18px !important;padding:0;margin:0 auto;display:inline-block;">แนะนำเว็บแทงบอล</h2>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="outter-wrapper divider-pro"></div>
         <div class="outter-wrapper centered paralax-block with-draw" style="background: url('images/withdraw/wd16.jpg');  background-position: 0px -28.75px" data-stellar-background-ratio="0.75">
            <div class="wrapper section-withdraw clearfix">
               <div class="col-md-6">
                  <header class="wow zoomIn">ฝาก-ถอน</header>
                  <p class="wow zoomIn">แจ้งฝาก-ถอน 24 ชั่วโมง ผ่านธนาคารชั้นนำ</p>
                  <ul class="withdraw">
                     <li class="wow bounceInLeft" data-wow-delay="0.2s"  >
                        <i class="fa fa-chevron-circle-right icon-maginr2" aria-hidden="true"></i> ฟรีค่าธรรมเนียมฝาก-ถอน 
                     </li>
                     <li class="wow bounceInLeft" data-wow-delay="0.4s"  >
                        <i class="fa fa-chevron-circle-right icon-maginr2" aria-hidden="true"></i> ฝากไม่เกิน 5 นาที ถอนไม่เกิน 15 นาที 
                     </li>
                     <li class="wow bounceInLeft" data-wow-delay="0.6s"  >
                        <i class="fa fa-chevron-circle-right icon-maginr2" aria-hidden="true"></i> ปลอดภัย หายห่วง ทุกข้อมูลของสมาชิก 
                     </li>
                  </ul>
               </div>
               <div class="col-md-6 last bank-list">
                  <ul class="bank-symbol">
                     <li class="wow flipInX" data-wow-delay="0.5s"><img class="img-responsive" src="images/bank/scb.png"></li>
                     <li class="wow flipInX" data-wow-delay="1s"><img class="img-responsive" src="images/bank/ktb.png"></li>
                     <li class="wow flipInX" data-wow-delay="1.5s"><img class="img-responsive" src="images/bank/bb.png"></li>
                     <li class="wow flipInX" data-wow-delay="2s"><img class="img-responsive" src="images/bank/kk.png"></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="outter-wrapper divider-pro"></div>
         <div class="section-all-service clearfix">
            <div class="col-md-12 last no-padding">
               <img class="img-responsive wow flash" data-wow-delay="2s" src="images/service/all-service.jpg">
            </div>
         </div>
         
      </div>
      <link href="style/style-main.css" rel="stylesheet" type="text/css" />
      <div class="outter-wrapper body-wrapper">
         <div class="wrapper clearfix" style="padding-bottom: 0;">
            <div class="col-1-1">
               <div class="simple-column">
                  <div class="heading heading-13">
                     <p>Contact Us</p>
                     <h2 class="wow zoomInUp">ติดต่อเรา <?=$fifa55Main;?></h2>
                     <br>
                  </div>
               </div>
            </div>
         </div>
         <section class="footer-contact">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="line-fb-container">
                        <div class="line-fb-inner2">
                           <div class="line2 wow zoomIn" data-wow-delay="1.4s">
                              <div class="con1">
                                 <img src="img/line-icon.png" alt="">
                              </div>
                              <div class="content-box">
                                 <a target="_blank" href="https://line.me/ti/p/"></a>
                              </div>
                           </div>
                           <div class="facebook2 wow zoomIn"  data-wow-delay="1.8s">
                              <div class="con1">
                                 <img src="img/fb-icon.png" alt="">
                              </div>
                              <a target="_blank" href="https://www.facebook.com/<?=$fifa55Main;?>"> <?=$fifa55Main;?></a>
                           </div>
                           <div class="clearfix"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
      <footer class="footer">
         <div class="footer-top footer-wrapper">
            <div class="container">
               <div class="row">
                  <div class="col-xs-12 col-md-4">
                     <p>
                        <img alt="logo-footer" class="logo" src="images/logo/logo.png" style="width: 204px;">
                     </p>
                     
                  </div>
                  <!-- /.row -->
                  <div class="col-xs-12 col-md-4">
                     <p class="foot-txt">
                        <span style="color: #ff665a;"><?=$fifa55Main;?></span>  เว็บแทงพนันออนไลน์ ที่มั่นคง เล่นง่าย ราคาดี เพิ่มความมั่นใจให้คุณอีก 100% ด้วยบริการฝาก - ถอน รวดเร็วทันใจ ตลอด 24 ชั่วโมง					
                     </p>
                     
                     <p>
                        <img src="images/bank/kk.png" width="40">
                        <img src="images/bank/scb.png" width="40">
                        <img src="images/bank/ktb.png" width="40">
                        <img src="images/bank/bb.png" width="40">
                     </p>
                  </div>
                  <!-- /.row -->
                  <div class="col-xs-12 col-md-2">
                     <div class="widget_nav_menu">
                        <h6 class="footer-top__headings">LINE ID: <span class="line-foot"></span></h6>
                        <img src="images/QR.jpg" height="160" >
                     </div>
                  </div>
                  <!-- /.row -->
               </div>
                  
                  
               <!-- /.row -->
            </div>
            <!-- /.footer -->
         </div>
         <!-- /.footer-top -->
         <div class="footer-bottom">
            <div class="container">
               <div class="footer-bottom__left">
                  <?=$fifa55Main;?> © <?=date('Y');?> all right reserved. <!-- Powered By <a href=""></a> -->
               </div>
               <div class="footer-bottom__right"></div>
            </div>
            <!-- /.container -->
         </div>
         <!-- /.footer-bottom -->
      </footer>
      <div class="visible-xs">
         <ul class="footer-fix">
            <li><a href="tel:"><img src="images/contact/svg/mobile-phone2.svg"></a></li>
            <li><a href="https://line.me/ti/p/" target="_blank"><img src="images/contact/svg/line.svg" alt="get_option('line_name')"></a></li>
            <li> <a href="https://www.facebook.com/<?=$fifa55Main;?>" target="_blank"><img src="images/contact/svg/facebook.svg"></a> </li>
         </ul>
      </div>
      <a id="banner-pop" style="display: none; cursor: pointer;"><img class="img-responsive" src="images/fifa55-popup.html"  onclick="closeFunction();" /></a>
      </div>
      <link href="style/style-switcher.css" rel="stylesheet">
      <!-- FontAwesome 4.3.0 -->
      <link href="plugins/font-awesome-4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
      <!-- Pace loading -->
      <link href="plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
      <script src="plugins/pace/pace.min.js" type="text/javascript"></script>
      <!-- Slide Banner -->
      <script type="text/javascript" src="js/jssor.slider.mini.js"></script>
      <link href="plugins/jsor/jsor_style.css" rel="stylesheet" type="text/css" />
      <link rel="stylesheet" type="text/css" href="style/jquery.sidr.light.css">
      <link rel="stylesheet" type="text/css" href="js/animate.css-master/animate.min.css">
      <script type="text/javascript" src="js/animate.css-master/dist/wow.min.js"></script>  
      <script type="text/javascript" src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script> 
      <!-- /.boxed-container -->
      <script type="text/javascript" src="js/jquery.sidr.js"></script>
      <script type="text/javascript" src="js/cleantabs.jquery.js"></script>
      <script type="text/javascript" src="js/fitvids.min.js"></script>
      <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
      <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
      <script type="text/javascript" src="js/toggle.js"></script>
      <script type="text/javascript" src="js/banner_sildes.js"></script>  
      <script type="text/javascript" src="js/main.js"></script>
      <script type="text/javascript" src="js/contactform.js"></script>  
      <!-- Add fancyBox -->
      <link rel="stylesheet" href="js/fancybox/source/jquery.fancybox3899.css?v=2.1.6" type="text/css" media="screen" />
      <script type="text/javascript" src="js/fancybox/source/jquery.fancybox.pack3899.js?v=2.1.6"></script>
      <script> new WOW().init(); </script>
      <script type="text/javascript">
         var popup_val = 'open';
            $(function(){
              if (!Modernizr.svg) {
                $('img[src*=".svg"]').attr('src', function() {
                  return $(this).attr('src').replace('.svg', '.png');
                });
              }
              $( ".fancybox-wrap" ).click(function() {
         			 	alert("555");
                 });
         /*
             if(popup_val=="open"){
         		$("#banner-pop").fancybox({
         			 helpers     : {
         		            	overlay : {
         		               		 css      : {
         		                    	cursor : 'default',
         								'background' : 'rgba(00, 00, 00, 0.9)',
         		                	},
         		                closeClick: false,
         		            }
         		        },
         			padding: 0,
         			'autoScale': true,
         			'autoDimensions': true,
         	        'centerOnScroll': true,
         			'afterClose'  : function() {
         				// $.post( "close_popup" );
                      }
         		}).trigger('click');  
         	}
         	*/
            });
         function closeFunction(){
         	 $(".fancybox-overlay").css("display","none");
         	 window.open('https://line.me/ti/p/', '_blank');
         }
      </script>
      <style>
         .fancybox-overlay{
         z-index: 99999999 !important;
         }
         .fancybox-wrap{
         z-index: 999999999 !important;
         }
         .fancybox-inner{
         min-width: 350px !important;
         min-height: 350px !important;
         }
         .footer-fix {
         z-index: 99;
         position: fixed;
         bottom: 0;
         left: 0;
         right: 0;
         padding: 0;
         margin: 0;
         overflow: hidden;
         background: #c1212c;
         background: -moz-linear-gradient(top, #c1212c 0, #7c050a 100%);
         background: -webkit-linear-gradient(top, #c1212c 0, #7c050a 100%);
         background: linear-gradient(to bottom, #c1212c 0, #7c050a 100%);
         filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#c1212c', endColorstr='#7c050a', GradientType=0);
         }
         .footer-fix li:nth-child(1) {
         border-right: 1px solid #bb4a4a;
         }
         .footer-fix li:nth-child(2) {
         border-right: 1px solid #bb4a4a;
         }
         .footer-fix li {
         float: left;
         width: 33.33%;
         /* 	    width: 50%; */
         list-style: none;
         text-align: center;
         padding: 5px 0; 
         /* 		padding: 10px 0; */
         }
         .footer-fix li img {
         height: 45px;
         }
         @media screen and (max-width: 767px) {
         .visible-xs {
         display: block !important;
         }
         }
         @media screen and (max-width: 770px) {
         .visible-xs {
         display: block !important;
         }
         }	
      </style>
   </body>
</html>